## Module <om_account_asset>

#### 29.04.2022
#### Version 14.0.7.5.0
##### FIX
- asset creation error from JE

#### 28.02.2022
#### Version 14.0.7.4.0
##### IMP
- remove deprecated method

#### 18.01.2022
#### Version 14.0.7.3.1
##### FIX
- asset

#### 02.01.2022
#### Version 14.0.7.3.0
##### FIX
- asset

#### 31.12.2021
#### Version 14.0.7.2.0
##### FIX
- validation error on resetting to draft for validated assets

#### 31.12.2021
#### Version 14.0.7.1.0
##### FIX
- singleton error

#### 30.12.2021
#### Version 14.0.7.0.0
##### FIX
- asset duplicate creation on reset to draft, float to monetory, 
multi currency update

#### 24.12.2021
#### Version 14.0.6.0.0
##### FIX
- asset

#### 22.12.2021
#### Version 14.0.5.0.0
##### IMP
- remove deprecated method

#### 08.12.2021
#### Version 14.0.4.0.0
##### IMP
- security
